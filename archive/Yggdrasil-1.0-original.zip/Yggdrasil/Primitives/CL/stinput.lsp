(SETQ *stinput* *STANDARD-INPUT*)
      